#ifndef __LINUX_CACHE_WRAPPER_H
#define __LINUX_CACHE_WRAPPER_H 1

#include_next <linux/cache.h>

#ifndef __ro_after_init
#define __ro_after_init
#endif

#endif
